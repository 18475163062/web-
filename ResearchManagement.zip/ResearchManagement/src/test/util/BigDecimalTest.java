package util;

import java.math.BigDecimal;

public class BigDecimalTest {

    public static void main(String[] args) {
        BigDecimal o = new BigDecimal(0);
        System.out.println("o: " + o.add(new BigDecimal(6.00)));
    }
}
