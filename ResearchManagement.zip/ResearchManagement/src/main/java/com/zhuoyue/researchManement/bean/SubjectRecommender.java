package com.zhuoyue.researchManement.bean;

public class SubjectRecommender {
    private Long id;
    private Long subjectId;
    private String name;
    private String position;
    private String profession;
    private String unit;
    private String subname;
    private String recommend;
    private String nameS;
    private String positionS;
    private String professionS;
    private String unitS;
    private String subnameS;
    private String recommendS;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Long subjectId) {
        this.subjectId = subjectId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getSubname() {
        return subname;
    }

    public void setSubname(String subname) {
        this.subname = subname;
    }

    public String getRecommend() {
        return recommend;
    }

    public void setRecommend(String recommend) {
        this.recommend = recommend;
    }

    public String getNameS() {
        return nameS;
    }

    public void setNameS(String nameS) {
        this.nameS = nameS;
    }

    public String getPositionS() {
        return positionS;
    }

    public void setPositionS(String positionS) {
        this.positionS = positionS;
    }

    public String getProfessionS() {
        return professionS;
    }

    public void setProfessionS(String professionS) {
        this.professionS = professionS;
    }

    public String getUnitS() {
        return unitS;
    }

    public void setUnitS(String unitS) {
        this.unitS = unitS;
    }

    public String getSubnameS() {
        return subnameS;
    }

    public void setSubnameS(String subnameS) {
        this.subnameS = subnameS;
    }

    public String getRecommendS() {
        return recommendS;
    }

    public void setRecommendS(String recommendS) {
        this.recommendS = recommendS;
    }
}
