package com.zhuoyue.researchManement.exception;

/**
 * Created by 12413 on 2018/5/23.
 */
public class CurrentUserException extends RuntimeException {
    public CurrentUserException(String message) {
        super(message);
    }
}
