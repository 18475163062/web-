package com.zhuoyue.researchManement.enums;

public class RoleType {

    public static final String ADMIN = "admin";
    public static final String EXPERT = "expert";
    public static final String CITY_RESEARCH = "city_research";
    public static final String AREA_RESEARCH = "area_research";
    public static final String SCHOOL_RESEARCH = "school_research";
    public static final String SUBJECT_HOST = "subject_host";

}
