package com.zhuoyue.researchManement.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface TestDao
{
	Integer[] selectTest();
}
