package com.zhuoyue.researchManement.common;

import com.zhuoyue.researchManement.bean.SubjectChange;

public class SubjectChangeManager {

    private SubjectChange change;

}
