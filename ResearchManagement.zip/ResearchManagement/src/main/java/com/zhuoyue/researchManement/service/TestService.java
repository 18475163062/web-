package com.zhuoyue.researchManement.service;

public interface TestService
{
	Integer[] selectTest();
}
